//
//  EffectPlugin.cpp
//  MyEffect Plugin Source Code
//
//  Used to define the bodies of functions used by the plugin, as declared in EffectPlugin.h.
//

#include "EffectPlugin.h"

////////////////////////////////////////////////////////////////////////////
// EFFECT - represents the whole effect plugin
////////////////////////////////////////////////////////////////////////////

// Called to create the effect (used to add your effect to the host plugin)
extern "C" {
    CREATE_FUNCTION createEffect(float sampleRate) {
        ::stk::Stk::setSampleRate(sampleRate);
        
        //==========================================================================
        // UI controls, add or remove dials and whatnot by adding to this parameters const.
        
        
        const Parameters CONTROLS = {
            //  name,       type,              min, max, initial, size
            {   "In Gain",  Parameter::ROTARY, 0.0, 1.0, 0.0, AUTO_SIZE  },
            {   "Filter Cutoff",  Parameter::ROTARY, 0.0, 1.0, 1.0, AUTO_SIZE  },
            {   "Out gain",  Parameter::ROTARY, 0.0, 1.0, 0.5, AUTO_SIZE  },
            {   "Distortion type",  Parameter::MENU, {"Off", "Hard Clip","Quantisation","Rectification","Soft Clip", "Folding Distortion", "Asymmetric Distortion","Expander", "Quarter Circle"}, AUTO_SIZE  },
            {   "Modifier",    Parameter::ROTARY,0.0,1.0,0.5,AUTO_SIZE}, //only used for soft clip and asymmetric
            {   "Filter type",  Parameter::MENU, {"Off", "Pre","Post"}, AUTO_SIZE  }
          
        };

        const Presets PRESETS = {
            { "Preset 1", { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } },
            { "Preset 2", { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } },
            { "Preset 3", { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } },
        };

        return (APDI::Effect*)new MyEffect(CONTROLS, PRESETS);
    }
}

// Constructor: called when the effect is first created / loaded
MyEffect::MyEffect(const Parameters& parameters, const Presets& presets)
: Effect(parameters, presets)
{
    // Initialise member variables, etc.
}

// Destructor: called when the effect is terminated / unloaded
MyEffect::~MyEffect()
{
    // Put your own additional clean up code here (e.g. free memory)
}

// EVENT HANDLERS: handle different user input (button presses, preset selection, drop menus)

void MyEffect::presetLoaded(int iPresetNum, const char *sPresetName)
{
    // A preset has been loaded, so you could perform setup, such as retrieving parameter values
    // using getParameter and use them to set state variables in the plugin
}

void MyEffect::optionChanged(int iOptionMenu, int iItem)
{
    // An option menu, with index iOptionMenu, has been changed to the entry, iItem
}

void MyEffect::buttonPressed(int iButton)
{
    // A button, with index iButton, has been pressed
}

float hardClip(float input){ //take a float input, if sample is over 1 or -1 in amplitude, it clips it back                           //to these values, then returns it
    float output = input;
    
    if(output> 1) output = 1;
    if(output < -1) output = -1;
    
    return output;
}

float quantisationDist(float input){ //take float, truncate the input (16 bit reduction)
                                     //clip the output to 1,-1
    
    float output = input;
    
    output *= 16;
    output = trunc(output);
    output /= 16;
    
    if(output> 1) output = 1;
    if(output < -1) output = -1;
    
    return output;
}

float rectifier(float input){ //take input, if the output is below 0 then * -1 to make value positive
    float output = input;
    
    if(output < 0) output *= -1;
    
    return output;
    
}
float softClipDistortion(float input,float curveDegree){
    //take input, clip output if its over +/-1
    //if it's above 0, apply curve for distortion
    //same with below 0, then return output
    //Curve severity is based on modifier parameter
    float output = input;
    
    if(output> 1) output = 1;
    if(output < -1) output = -1;
    
    if(output > 0) output = 1 - pow(curveDegree,(input*-1));
    else output = -1 + pow(curveDegree,input);
    
    output *= curveDegree/(curveDegree-1);
    
    
    return output;
}

float foldingDist(float input){
    //takes input, if input is above 1
    //fold back sample value down
    //towards 0, if it's below -1, fold sample back up towards 0
        
    float output = input;
    
    if(output > 1) output = 1 - (output-1);
    if(output < -1) output = (-1*output) + (-1+output);
    
    return output;
}

float asymmetricDist(float input, float limit){
    //takes input, calulates lower bound for distortion
    //uses modifier to calculate this
    //if the input is above the limit, clip it to limit
    //same goes for opposing limit
    
    float output = input;
    float oppLimit = -1*(1.0 - limit);
    
    if(output > limit) output = limit;
    if(output < oppLimit) output = oppLimit;
    
    return output;
}

float parabolicExpander(float input){ //not working properly yet
    float output = 0;
    
    if(input > 0) output = pow(input,2);
    else output = pow(input,2) * -1;
    
    if(output > 1) output = 1;
    if(output < -1) output = -1;
    
    return output;
}

float quarterCircleDist(float input){
    //any other audio is limited to curve of line
    //sqrt(1 - (output+1)^2)
    //or same line * -1 for opposite side
    //Creates quarter circles on both axis
    
    
    float output = input;
    
    if(output > 0) output = sqrt(1-pow(output-1,2));
    if (output < 0) output = -1 * (sqrt(1-pow(output+1,2)));
    
    if(output > 1) output = 1;
    if(output < -1) output = -1;
    
    return output;
}


float bypassDist(float input){ //bypass
    return input;
}

// Applies audio processing to a buffer of audio
// (inputBuffer contains the input audio, and processed samples should be stored in outputBuffer)
void MyEffect::process(const float** inputBuffers, float** outputBuffers, int numSamples)
{
    float fIn0, fIn1, fOut0 = 0, fOut1 = 0; //sets up inputs and initialises outputs
                                            //avoids random memory assignment
    //set up buffers for processing input and output
    const float *pfInBuffer0 = inputBuffers[0], *pfInBuffer1 = inputBuffers[1];
    float *pfOutBuffer0 = outputBuffers[0], *pfOutBuffer1 = outputBuffers[1];
    
    
    float fInGain = pow(parameters[0], 3) * 24 + 1; //sets up parameters, scales and offsets to                                                          //allows for up to 25dB of gain
    
    float fOutGain = pow(parameters[2],3); //most sliders are cubed (smoother curved power)
    float fCutoff =  pow(parameters[1],3) * 7900 + 100; //scale and offset for 8000(Hz)
    float fShape = pow(parameters[4],3) * (1000-2) + 2; //scale and offset for 1000, setup with 1000-2 for                                                   //easy scalability
    float fSymmetryShape = parameters[4];
    int iMenuParam = parameters[3];
    int iFilterMenuParam = parameters[5];
    
    
    filter0.setCutoff(fCutoff); //setup lowpass biquad filter for each channel (stereo)
    filter1.setCutoff(fCutoff); //set to cutoff of parameter
    while(numSamples--)
    {
        
        // Get sample from input
        fIn0 = *pfInBuffer0++; //set new varaible to be current value in buffer
        fIn1 = *pfInBuffer1++;
        
        // Add your effect processing here
        fIn0 *= fInGain;
        fIn1 *= fInGain;
        
        if(iFilterMenuParam == 1) static_cast<void>(fIn0 = filter0.tick(fIn0)),fIn1 = filter1.tick(fIn1); //pre filter if 1 is chosen
        
        switch(iMenuParam){ //switch statement takes output from menu object
            case 0:
                fIn0 = bypassDist(fIn0); //call bypass function (both channels need it, not mono signal)
                fIn1 = bypassDist(fIn1);
                break;
            case 1:
                fIn0 = hardClip(fIn0); //call hard clip function
                fIn1 = hardClip(fIn1);
                break;
            case 2:
                fIn0 = quantisationDist(fIn0); //call quantisation distortion
                fIn1 = quantisationDist(fIn1);
                break;
            case 3:
                fIn0 = rectifier(fIn0); //rectify signal
                fIn1 = rectifier(fIn1);
                break;
            case 4:
                fIn0 = softClipDistortion(fIn0,fShape); //call softclip function, with shape parameter
                fIn1 = softClipDistortion(fIn1,fShape);
                break;
            case 5:
                fIn0 = foldingDist(fIn0); //call folding distortion function
                fIn1 = foldingDist(fIn1);
                break;
            case 6:
                fIn0 = asymmetricDist(fIn0,fSymmetryShape); //call asymmetric disortion,
                fIn1 = asymmetricDist(fIn1,fSymmetryShape); //with bounds set by shape param
                break;
            case 7:
                fIn0 = parabolicExpander(fIn0); //call expander function (not working yet)
                fIn1 = parabolicExpander(fIn1);
                break;
            case 8:
                fIn0 = quarterCircleDist(fIn0); //call quarter circle distortion
                fIn1 = quarterCircleDist(fIn1);
                //known problem about analysis on this effect as it breaks when input gain is applied
                //working on fix where function applies gain individually to distortion types.
                break;
            default:
                fIn0 = bypassDist(fIn0); //if cases break, default to bypass.
                fIn1 = bypassDist(fIn1);
                break;
        }
        
        
        if(iFilterMenuParam == 2) static_cast<void>(fIn0 = filter0.tick(fIn0)),fIn1 = filter1.tick(fIn1); //pre filter if 2 is chosen
        
        fOut0 = (fIn0 * fOutGain); //apply output/makeup gain
        fOut1 = (fIn1 * fOutGain);
        // Copy result to output
        *pfOutBuffer0++ = fOut0;
        *pfOutBuffer1++ = fOut1;
    }
}
